const express = require("express");
const router = new express.Router();
const controller = require("../users/users.controllers");
const auth = require('../../middleware/auth');

router.post('/login', controller.userLogin);
router.post('/users', controller.createUser);
router.post('/event', auth, controller.createEvent);
router.patch('/event/:id', controller.updateEvent);
router.delete('/event/:id', controller.deleteEvent);
router.get('/users', controller.getUsers);
router.get('/event/:id', controller.getEventById);

module.exports = router;