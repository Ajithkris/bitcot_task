const Users = require("../../models/user");
const Event = require("../../models/event");

const userLogin = async (req) => {
    try {
        const user = await Users.findByCredentials(req.body.email, req.body.phone_number);
        const token = await user.generateAuthToken();
        return ({ user, token });
    } catch (e) {
        throw new Error(e)
    }
};

const createUser = async (req) => {
    const user = new Users(req.body);
    try {
        await user.save();
        const token = await user.generateAuthToken();
        return ({ user, token });
    } catch (e) {
        throw new Error(e);
    }
};

const createEvent = async (req) => {
    try {
        const event = new Event({
            user_id: req.user._id,
            name: req.body.name,
            description: req.body.description,
            start_date: req.body.start_date,
            end_date: req.body.end_date,
            city: req.body.city
        });
        const a = await event.save(req.body);

        return ({ a });

    } catch (e) {
        throw new Error(e);
    }
};

const updateEvent = async (req) => {
    try {
        var event = await Event.findByIdAndUpdate(req.params.id, req.body);
        return event;
    } catch (e) {
        throw new Error(e);
    }
};

const deleteEvent = async (req) => {
    try {
        var event = await Event.findByIdAndDelete(req.params.id);
        return event;
    } catch (e) {
        throw new Error(e);
    }
};

const getUsers = async (req) => {
    try {
        const users = await Users.find(req.query);
        return users;
    } catch (e) {
        throw new Error(e);
    }
};

const getEventById = async (req) => {
    try {
        const event = await Event.find({ "user_id": req.params._id });
        return event;
    } catch (e) {
        throw new Error(e);
    }
};


module.exports = {
    userLogin: userLogin,
    createUser: createUser,
    createEvent: createEvent,
    updateEvent: updateEvent,
    deleteEvent: deleteEvent,
    getUsers: getUsers,
    getEventById: getEventById
}
