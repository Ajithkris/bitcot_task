const User = require("../../models/user");
const Event = require("../../models/event");
const service = require('./users.service');

const userLogin = async (req, res) => {
    service.userLogin(req).then((user) => {
        res.cookie("jwt", user.token, {
            expires: new Date(Date.now() + 700000),
            httpOnly: true
        });
        res.status(200).send(user);
    }).catch((e) => {
        res.status(500).send(e)
    })
};

const createUser = async (req, res) => {
    service.createUser(req).then((user) => {
        res.cookie("jwt", user.token, {
            expires: new Date(Date.now() + 700000),
            httpOnly: true
        });
        res.status(200).send(user);
    }).catch((e) => {

        res.status(500).send(e);
    })
};

const createEvent = async (req, res) => {
    service.createEvent(req).then((event) => {
        res.status(200).send(event);
    }).catch((e) => {
        res.status(500).send(e);
    })
};

const updateEvent = async (req, res) => {
    service.updateEvent(req).then((event) => {
        res.status(200).send(event);
    }).catch((e) => {
        res.status(500).send(e);
    })
};

const deleteEvent = async (req, res) => {
    service.deleteEvent(req).then((event) => {
        res.status(200).send(event);
    }).catch((e) => {
        res.status(500).send(e);
    })
};

const getUsers = async (req, res) => {
    service.getUsers(req).then((users) => {
        if (!users.length) {
            return res.status(404).send({});
        }
        res.status(200).send(users);
    }).catch((e) => {
        res.status(500).send(e);
    })
};

const getEventById = async (req, res) => {
    service.getEventById(req).then((user) => {
        if (!user) {
            return res.status(404).send({});
        }
        res.status(200).send(user);
    }).catch((e) => {
        res.status(500).send(e);
    })
};

module.exports = {
    userLogin: userLogin,
    createUser: createUser,
    createEvent: createEvent,
    updateEvent: updateEvent,
    deleteEvent: deleteEvent,
    getUsers: getUsers,
    getEventById: getEventById
}

