const express = require("express");
const app = express();
app.use(express.json());

require("./db/mongoose");
const usersRouters = require('./routers/users');
const userService = require('./routers/users/users.service')

app.use('/api', usersRouters);


app.listen(3000, () => {
    console.log("server setup in port 3000");
});