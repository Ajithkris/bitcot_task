const mongoose = require("mongoose");

const EventSchema = new mongoose.Schema({
    name: {
        type: String,

        trim: true
    },
    description: {
        type: String,
        trim: true
    },
    start_date: {
        type: Date
    },
    end_date: {
        type: Date
    },
    city: {
        type: String
    },
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
    }
});

const Event = mongoose.model("Event", EventSchema);
module.exports = Event;