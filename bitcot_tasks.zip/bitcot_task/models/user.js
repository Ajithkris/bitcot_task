const mongoose = require("mongoose");
const validator = require("validator");
const jwt = require("jsonwebtoken");

const UserSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        trim: true
    },
    email: {
        type: String,
        required: true,
        unique: true,
        trim: true,
        lowerCase: true,
        validate: (value) => {
            if (!validator.isEmail(value)) {
                throw new Error("please enter valid email");
            }
        }
    },
    phone_number: {
        type: String,
        maxlength: 10
    },
    role: {
        type: String,
        enum: ['ADMIN', 'USER'],
        default: 'USER'
    },
    tokens: [{
        token: {
            type: String,
            required: true
        }
    }]

});

UserSchema.methods.generateAuthToken = async function () {
    const user = this;
    const token = jwt.sign({ _id: user.id.toString() }, 'AJITHKUMAR');
    await user.save();
    return (token);
}

UserSchema.statics.findByCredentials = async function (email, phone_number) {
    const user = await User.findOne({ email: email, phone_number: phone_number });
    if (!user || user == null) {
        throw new Error("Unable to login")
    }
    return user;
}

const User = mongoose.model("User", UserSchema);
module.exports = User;